<div class="nav-container p-md-4 p-2">
    @include('front.partials._nav')
</div>