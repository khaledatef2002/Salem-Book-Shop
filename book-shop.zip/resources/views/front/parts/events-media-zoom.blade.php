<!-- Modal -->
<div class="modal fade" id="mediaZoom" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog d-flex justify-content-center">
        <div class="modal-content">
            <i type="button" class="fa-solid fa-circle-xmark" data-bs-dismiss="modal" aria-label="Close"></i>
            <div class="image">

            </div>
        </div>
    </div>
</div>