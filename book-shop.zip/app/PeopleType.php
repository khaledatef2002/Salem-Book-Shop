<?php

namespace App;

enum PeopleType: string
{
    case Author = 'author';
    case Instructor = 'instructor';
}
