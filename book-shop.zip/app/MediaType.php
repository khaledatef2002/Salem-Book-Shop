<?php

namespace App;

enum MediaType: string
{
    case Image = 'image';
    case Youtube = 'youtube';
}
