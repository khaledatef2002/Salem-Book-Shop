

<?php $__env->startSection('title', 'All Events'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.partials._nav', ['rounded' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="event-info" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-5">
                <div class="event-image-holder d-flex justify-content-center align-items-center rounded-3">
                    <img src="<?php echo e(asset($event->cover)); ?>">
                </div>
            </div>
            <div class="col-7 ps-2">
                <h2><?php echo e($event->title); ?></h2>
                <hr>
                <p class="mb-2">
                    <i class="fa-solid fa-person-chalkboard me-1"></i>
                    <?php echo e(implode(',', $event->instructors()->pluck('name')->toArray())); ?>

                </p>
                <p class="mb-2 d-flex align-items-center gap-2" id="event-info">
                    <i class="fa-solid fa-clipboard-user"></i>
                    <span class="counter"><?php echo e($event->attendants->count()); ?></span>
                    <span id="auth-attendance-info" style="display: <?php echo e(Auth::check() && $event->authAttendants->count() ? 'block' : 'none'); ?>">(<?php echo app('translator')->get('custom.events.attended'); ?> <i class="fa-solid fa-check text-success"></i>)</span>
                </p>
                <?php if($event->date < now()): ?>
                    <div class="d-flex flex-column align-items-center mb-3" style="width: fit-content">
                        <span class="fw-bold fs-1"><?php echo e(number_format($event->avg_review, 1)); ?></span>
                        <span>
                            <?php for($i = 0; $i < round($event->avg_review); $i++): ?>
                                <i class="fa-solid fa-star text-warning"></i>
                            <?php endfor; ?>
                            <?php for($i = 0; $i < 5 - round($event->avg_review); $i++): ?>
                                <i class="fa-regular fa-star"></i>
                            <?php endfor; ?>
                        </span>
                    </div>
                    <p class="mb-2">
                        <i class="fa-solid fa-message"></i> <?php echo e($event->reviews->count()); ?> <?php echo app('translator')->get('custom.reviews'); ?>
                    </p>
                <?php endif; ?>
                <p>
                    <i class="fa-solid fa-calendar-days"></i> <bdi><?php echo e($event->date->format('Y, M d h:ia')); ?></bdi>
                </p>
            </div>
        </div>
        <div class="row mt-2">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link active border-0" aria-current="page" data-bs-toggle="list" href="#attendance"><?php echo app('translator')->get('custom.events.attendance'); ?></a>
                </li>
                <?php if($event->date < now()): ?>
                    <li class="nav-item">
                        <a class="nav-link border-0" aria-current="page" data-bs-toggle="list" href="#reviews"><?php echo app('translator')->get('custom.reviews'); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link border-0" aria-current="page" data-bs-toggle="list" href="#media"><?php echo app('translator')->get('custom.events.media'); ?></a>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="card border-0">
                <div class="card-body">
                    <div class="tab-content p-3">
                        <div class="tab-pane active show" id="attendance" role="tabpanel">
                            <?php echo $__env->make('front.parts.events-attendance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <?php if($event->date < now()): ?>
                            <div class="tab-pane" id="reviews" role="tabpanel">
                                <?php echo $__env->make('front.parts.events-reviews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="tab-pane" id="media" role="tabpanel">
                                <?php echo $__env->make('front.parts.events-media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
    <script src="<?php echo e(asset('front/js/single-event.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/events/single-event.blade.php ENDPATH**/ ?>