<nav class="navbar navbar-expand-lg bg-light rounded-<?php echo e($rounded ?? '4'); ?> px-md-3">
    <div class="container-fluid d-flex justify-content-start">
        <div class="d-flex flex-lg-grow-0 flex-fill">
            <div class="d-flex flex-fill justify-content-between">
                <a class="navbar-brand d-flex align-items-center" href="<?php echo e(route('front.index')); ?>">
                    <img src="<?php echo e(asset('front')); ?>/imgs/logo.png" width="60px">
                </a>
                <button class="navbar-toggler border-0 ms-auto" type="button" data-bs-toggle="collapse" data-bs-target=".navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </div>
        </div>
        <div class="collapse navbar-collapse navbarSupportedContent ms-2">
            <ul class="navbar-nav mb-2 mb-lg-0 d-flex gap-4">
                <li class="nav-item text-center">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('front.index')); ?>"><?php echo app('translator')->get('custom.home'); ?></a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="false">
                      <?php echo app('translator')->get('custom.books'); ?>
                    </a>
                    <div class="dropdown-menu border-0">
                        <?php $__currentLoopData = $book_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" href="<?php echo e(route('front.book.index', ['category_id' => $category->id])); ?>"><?php echo e($category->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <hr class="my-1">
                        <a class="dropdown-item" href="<?php echo e(route('front.book.index')); ?>"><?php echo app('translator')->get('custom.all-books'); ?></a> 
                    </div>
                </li>
                <li class="nav-item text-center">
                    <a class="nav-link" href="<?php echo e(route('front.quote.index')); ?>"><?php echo app('translator')->get('custom.quotes'); ?></a>
                </li>
                <li class="nav-item text-center">
                    <a class="nav-link" href="<?php echo e(route('front.event.index')); ?>"><?php echo app('translator')->get('custom.events'); ?></a>
                </li>
                <li class="nav-item text-center">
                    <a class="nav-link" href="#"><?php echo app('translator')->get('custom.blogs'); ?></a>
                </li>
                <li class="nav-item text-center">
                    <a class="nav-link" href="#"><?php echo app('translator')->get('custom.news'); ?></a>
                </li>
            </ul>
        </div>
        <div class="collapse navbar-collapse navbarSupportedContent text-center d-lg-flex justify-content-end">
            <?php if(Auth::check()): ?>
                <div class="auth-list nav-item dropdown">
                    <a class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="false">
                        <i class="fa-solid fa-user"></i>
                    </a>
                    <div class="dropdown-menu border-0 px-2">
                        <div class="user-info d-flex flex-column align-items-center">
                            <div class="user-image">
                                <img src="<?php echo e(Auth::user()->display_image); ?>" alt="">
                            </div>
                            <p class="mb-0 fw-bold"><?php echo e(ucfirst(Auth::user()->full_name)); ?></p>
                            <span><?php echo e(Auth::user()->email); ?></span>
                        </div>
                        <hr class="my-2">
                        <a class="dropdown-item" href="<?php echo e(route('front.profile')); ?>"><i class="fa-solid fa-user"></i> <?php echo app('translator')->get('custom.profile'); ?></a>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="dropdown-item"><i class="fa-solid fa-right-from-bracket"></i> <?php echo app('translator')->get('custom.logout'); ?></button>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div class="mb-lg-0 mb-2 d-flex align-items-center">
                    <a href="<?php echo e(route('login')); ?>" class="text-decoration-none me-2 fs-5 ms-lg-0 ms-4" id="log-in-button"><?php echo app('translator')->get('custom.login'); ?></a>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-primary rounded-5 px-4 py-2 fw-bold ms-2" id="sign-up-button"><?php echo app('translator')->get('custom.signup'); ?></a>
                </div>
            <?php endif; ?>
            <?php if(LaravelLocalization::getCurrentLocale() == 'ar'): ?>
                <a href="<?php echo e(LaravelLocalization::getLocalizedURL('en')); ?>"><img src="<?php echo e(asset('front')); ?>/imgs/en.svg" height="25" class="ms-3 rounded-2" role="button"></a>
            <?php else: ?>
                <a href="<?php echo e(LaravelLocalization::getLocalizedURL('ar')); ?>"><img src="<?php echo e(asset('front')); ?>/imgs/ar.svg" height="25" class="ms-3 rounded-2" role="button"></a>
            <?php endif; ?>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/partials/_nav.blade.php ENDPATH**/ ?>