

<?php $__env->startSection('title', __('custom.about')); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.partials._nav', ['rounded' => '0'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="about-us-page" class="py-5">
    <div class="container text-center">
        <div class="card border-0 p-4 rounded-4">
            <a href="https://suhail.ae"><img src="<?php echo e(asset('front/imgs/sohail-logo.png')); ?>" height="150" class="mb-4"></a>
            <h1 class="fw-bold fs-1 mb-4"><?php echo app('translator')->get('custom.about.title'); ?></h1>
            <p class="fs-5"><?php echo app('translator')->get('custom.about.p1'); ?></p>
            <p class="fs-5"><?php echo app('translator')->get('custom.about.p2'); ?></p>
            <p class="fs-5"><?php echo app('translator')->get('custom.about.p3'); ?></p>
            <p class="fs-5"><?php echo app('translator')->get('custom.about.p4'); ?></p>
            <p class="fs-5"><?php echo app('translator')->get('custom.about.p5'); ?></p>
            <p class="fs-5"><?php echo app('translator')->get('custom.about.p6'); ?></p>
            <p class="fs-5 mb-0"><?php echo app('translator')->get('custom.about.p7'); ?></p>
            <a href="https://suhail.ae" class="fw-bold">suhail.ae</a>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/about.blade.php ENDPATH**/ ?>