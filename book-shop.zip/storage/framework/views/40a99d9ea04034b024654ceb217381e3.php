<div class="d-flex justify-content-between align-items-center">
    <h2><?php echo app('translator')->get('custom.events.attendance'); ?></h2>
    
    <?php if($event->date > now()): ?>
        
        <?php if(Auth::check()): ?>
            <form id="unattend-form" style="display: <?php echo e($event->authAttendants->count() ? 'block' : 'none'); ?>" onsubmit="unattend_event(event, this, <?php echo e($event->id); ?>)">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger" type="submit"><?php echo app('translator')->get('custom.events.unattend'); ?></button>
            </form>    
            <form id="attend-form" style="display: <?php echo e($event->authAttendants->count() ? 'none' : 'block'); ?>" onsubmit="attend_event(event, this, <?php echo e($event->id); ?>)">
                <?php echo csrf_field(); ?>
                <button class="btn btn-primary" type="submit"><?php echo app('translator')->get('custom.events.attend'); ?></button>
            </form> 
        
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="text-decoration-none"><?php echo app('translator')->get('custom.events.login-to-attend'); ?></a>
        <?php endif; ?>
    <?php endif; ?>
</div>

<div id="auth-attendance">
    <?php if(Auth::check() && $event->authAttendants->count()): ?>
            <?php echo $__env->make('front.parts.events-auth-attendance', ['attendance' => $event->authAttendants->first()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div>
<?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(!(auth()->check() && $user->id == auth()->user()->id)): ?>
        <div class="attendance-item">
            <hr>
            <div class="user-info d-flex align-items-center gap-3 mb-1">
                <div class="user_image d-flex justify-content-center align-items-center">
                    <img src="<?php echo e($user->display_image); ?>">
                </div>
                <div>
                    <p class="mb-0 fw-bold"><?php echo e($user->full_name); ?></p>
                    <p class="mb-0" id="auth-attend-date"><?php echo e($user->created_at->format('Y/m/d h:i:sa')); ?></p>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<p id="no-attendance-message" class="mx-auto mt-2" style="display: <?php echo e($attendance->count() ? 'none' : 'block'); ?>"><?php echo app('translator')->get('custom.events.no-attendance'); ?></p>

<?php echo e($attendance->appends(['reviews_page' => request('reviews_page')])->links('pagination::bootstrap-4')); ?><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/parts/events-attendance.blade.php ENDPATH**/ ?>