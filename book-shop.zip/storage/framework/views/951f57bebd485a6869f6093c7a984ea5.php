<header class="pb-2">
    <div class="hero text-center pb-5 pt-4 px-2">
        <img src="<?php echo e(asset('front')); ?>/imgs/books-header.png" class="mb-5">
        <h1 class="text-white"><?php echo app('translator')->get('custom.header.title'); ?></h1>
        <h2 class="my-3 fw-bold"><?php echo app('translator')->get('custom.header.sub-title'); ?></h2>
        <p class="text-white"><?php echo app('translator')->get('custom.header.text'); ?></p>
    </div>
</header><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/partials/_header.blade.php ENDPATH**/ ?>