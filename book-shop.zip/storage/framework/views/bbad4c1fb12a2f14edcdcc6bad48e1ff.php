<script>
    var rtl = <?php echo e(LaravelLocalization::getCurrentLocaleDirection() == "rtl" ? "true" : "false"); ?>

</script>
<script src="<?php echo e(asset('front')); ?>/libs/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('front')); ?>/libs/jquery/jquery-3.6.4.min.js"></script>
<script src="<?php echo e(asset('front')); ?>/libs/owlcarousel/owl.carousel.js"></script>
<script src="<?php echo e(asset('front')); ?>/libs/sweetalert2/sweet.js"></script>
<script src="<?php echo e(asset('front')); ?>/js/main.js"></script>
<?php echo $__env->yieldContent('custom-js'); ?><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/partials/_js-libs.blade.php ENDPATH**/ ?>