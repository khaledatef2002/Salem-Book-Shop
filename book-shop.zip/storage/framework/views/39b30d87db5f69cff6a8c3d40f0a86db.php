<!DOCTYPE html>
<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>">
<head>
    <?php echo $__env->make('front.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('front.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('front.partials._js-libs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/main.blade.php ENDPATH**/ ?>