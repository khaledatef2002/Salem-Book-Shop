

<?php $__env->startSection('title', 'All Books'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.partials._nav', ['rounded' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="book-info" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-3">
                <div class="owl-carousel book-carousel pe-0">
                    <?php $__currentLoopData = $book->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="book-image-holder d-flex justify-content-center align-items-center">
                            <img src="<?php echo e(asset($image->url)); ?>" alt="" srcset="">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-9 ps-4">
                <h2><?php echo e($book->title); ?></h2>
                <hr>
                <p>
                    <i class="fa-solid fa-pen-nib"></i> <?php echo e($book->author->name); ?>

                </p>
                <p>
                    <a class="text-decoration-none" href="<?php echo e(route('front.book.index', ['category_id' => $book->category->id])); ?>"><i class="fa-solid fa-layer-group"></i> <?php echo e($book->category->name); ?></a>
                </p>
                <p>
                    <i class="fa-solid fa-message"></i> <?php echo e($book->reviews->count()); ?> <?php echo app('translator')->get('custom.reviews'); ?>
                </p>
                <div class="d-flex flex-column align-items-center mb-3" style="width: fit-content">
                    <span class="fw-bold fs-1"><?php echo e(number_format($book->avg_review, 1)); ?></span>
                    <span>
                        <?php for($i = 0; $i < round($book->avg_review); $i++): ?>
                            <i class="fa-solid fa-star text-warning"></i>
                        <?php endfor; ?>
                        <?php for($i = 0; $i < 5 - round($book->avg_review); $i++): ?>
                            <i class="fa-regular fa-star"></i>
                        <?php endfor; ?>
                    </span>
                </div>
                <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#book-read"><?php echo app('translator')->get('custom.books.read'); ?></a>
                <?php if($book->downloadable): ?>
                    <a href="<?php echo e(route('front.books.download', $book)); ?>" class="btn btn-success" target="_blank"><?php echo app('translator')->get('custom.books.download'); ?></a>
                <?php else: ?>
                    <p><?php echo app('translator')->get('custom.books.no-download'); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link active border-0" aria-current="page" data-bs-toggle="list" href="#reviews"><?php echo app('translator')->get('custom.reviews'); ?></a>
                </li>
            </ul>
            <div class="card border-0">
                <div class="card-body">
                    <div class="tab-content p-3">
                        <div class="tab-pane fade show active" id="reviews" role="tabpanel">
                            <?php if(Auth::check()): ?>
                                <form id="add-review-form" class="review-form" style="display: <?php echo e($book->authReview->count() ? 'none' : 'block'); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                                    <p class="fw-bold fs-4 mb-0"><?php echo app('translator')->get('custom.book.review.rate-this-book'); ?></p>
                                    <p class="mb-0"><?php echo app('translator')->get('custom.book.review.tell-others'); ?></p>
                                    <div class="stars my-2">
                                        <i class="fa-regular fa-star fs-4" data-id="1" role="button"></i>
                                        <i class="fa-regular fa-star fs-4" data-id="2" role="button"></i>
                                        <i class="fa-regular fa-star fs-4" data-id="3" role="button"></i>
                                        <i class="fa-regular fa-star fs-4" data-id="4" role="button"></i>
                                        <i class="fa-regular fa-star fs-4" data-id="5" role="button"></i> 
                                    </div>
                                    <textarea name="review_text" class="form-control" placeholder="Leave comment..." rows="4"></textarea>
                                    <button class="btn btn-primary mt-2 px-3 d-block ms-auto" type="submit"><?php echo app('translator')->get('custom.send'); ?></button>
                                </form>
                                <div id="auth-review" class="review" style="display: <?php echo e($book->authReview->count() ? 'block' : 'none'); ?>">
                                    <?php echo $__env->make('front.parts.book-auth-review', ['review' => $book->authReview->first()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <form id="edit-review-form" class="review-form" style="display: none">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                                    <p class="fw-bold fs-4 mb-0"><?php echo app('translator')->get('custom.book.review.rate-this-book'); ?></p>
                                    <p class="mb-0"><?php echo app('translator')->get('custom.book.review.tell-others'); ?></p>
                                    <div class="stars my-2">
                                        <i class="fa-regular fa-star fs-4" data-id="1" role="button"></i>
                                        <i class="fa-regular fa-star fs-4" data-id="2" role="button"></i>
                                        <i class="fa-regular fa-star fs-4" data-id="3" role="button"></i>
                                        <i class="fa-regular fa-star fs-4" data-id="4" role="button"></i>
                                        <i class="fa-regular fa-star fs-4" data-id="5" role="button"></i> 
                                    </div>
                                    <textarea name="review_text" class="form-control" placeholder="Leave comment..." rows="4"></textarea>
                                    <div class="d-flex justify-content-end gap-2">
                                        <button class="btn btn-primary mt-2 px-3 d-block" type="submit"><?php echo app('translator')->get('custom.save'); ?></button>
                                        <button class="btn btn-secondary mt-2 px-3 d-block cancel_edit_review" type="button"><?php echo app('translator')->get('custom.cancel'); ?></button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <p class="fw-bold fs-4 mb-0"><?php echo app('translator')->get('custom.book.review.rate-this-book'); ?></p>
                                <a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-right-to-bracket"></i> <?php echo app('translator')->get('custom.book.review.sign-in-to-rate'); ?></a>
                            <?php endif; ?>
                            <?php if($reviews->count() > 0): ?>
                                <div class="reviews-list">
                                    <ul class="list-style-none ps-0 mb-0">
                                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($review->user_id != Auth::user()?->id): ?>
                                                <hr>
                                                <li class="d-flex flex-column gap-2 review">
                                                    <div>
                                                        <div class="user-info d-flex align-items-center gap-3 mb-1">
                                                            <div class="user_image d-flex justify-content-center align-items-center">
                                                                <img src="<?php echo e($review->user->display_image); ?>" alt="">
                                                            </div>
                                                            <p class="mb-0 fw-bold"><?php echo e($review->user->full_name); ?></p>
                                                        </div>
                                                        <div class="meta-data d-flex gap-3">
                                                            <p class="mb-0">
                                                                <?php for($i = 0; $i < round($review->review_star); $i++): ?>
                                                                    <i class="fa-solid fa-star text-warning"></i>
                                                                <?php endfor; ?>
                                                                <?php for($i = 0; $i < 5 - round($review->review_star); $i++): ?>
                                                                    <i class="fa-regular fa-star"></i>
                                                                <?php endfor; ?>
                                                                (<?php echo e($review->review_star); ?>)
                                                            </p>
                                                            <p class="mb-0"><?php echo e($review->created_at->format('Y/m/d')); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="review-info">
                                                        <p class="fs-4 mb-0"><?php echo e($review->review_text); ?></p>
                                                    </div>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php echo e($reviews->links('pagination::bootstrap-4')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="book-read" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body p-0 vh-100">
          <button class="btn btn-danger px-5 m-4" data-bs-dismiss="modal" aria-label="Close"><?php echo app('translator')->get('custom.close'); ?></button>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
    <script>
        var book_id = <?php echo e($book->id); ?>

        var csrf = "<?php echo e(csrf_token()); ?>"
    </script>
    <script src="<?php echo e(asset('front/js/single-book.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/books/single-book.blade.php ENDPATH**/ ?>