<div class="nav-container p-md-4 p-2">
    <?php echo $__env->make('front.partials._nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/partials/_nav-container.blade.php ENDPATH**/ ?>