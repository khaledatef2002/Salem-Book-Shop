<div class="d-flex flex-wrap">
    <?php if($events->count()): ?>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="items col-12 p-1">
                    <div class="card">
                        <div class="card-body d-flex gap-3">
                            <div class="event-image rounded-3 d-flex justify-content-center align-items-center">
                                <img src="<?php echo e(asset($event->cover)); ?>" alt="">
                            </div>
                            <div class="event-content flex-fill py-2 d-flex flex-column justify-content-between">
                                <div>
                                    <div class="event-content-header d-flex justify-content-between">
                                        <h2 class="fs-4 text-center text-dark fw-bold"><?php echo e($event->title); ?></h2>
                                        <span class="time fw-bold">
                                            <bdi><?php echo e($event->date->format("Y, M d h:ia")); ?></bdi>
                                            <?php if($event->date < now()): ?>
                                                (<i class="fa-solid fa-check-double text-success"></i>)
                                            <?php else: ?>
                                                <i class="fa-solid fa-hourglass-half text-warning"></i>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    <div class="event-description">
                                        <?php echo e($event->description); ?>

                                    </div>
                                </div>
                                <div>
                                    <div class="tags d-flex align-items-end gap-3">
                                        <div class="instructors">
                                            <i class="fa-solid fa-person-chalkboard me-1"></i>
                                            <?php echo e(implode(',', $event->instructors()->pluck('name')->toArray())); ?>

                                        </div>
                                        <div class="attendance">
                                            <i class="fa-solid fa-clipboard-user"></i>
                                            <?php echo e($event->attendants->count()); ?>

                                            <?php if(Auth::check() && $event->authAttendants->count()): ?>
                                                (<?php echo app('translator')->get('custom.events.attended'); ?> <i class="fa-solid fa-check text-success"></i>)
                                            <?php endif; ?>
                                        </div>
                                        <div class="reviews">
                                            <i class="fa-solid fa-message"></i>
                                            <?php echo e($event->reviews->count()); ?>

                                        </div>
                                        <div class="d-flex flex-fill justify-content-end align-items-center">
                                            <a href="<?php echo e(route('front.event.show', $event)); ?>" class="text-decoration-none">Details <i class="fa-solid fa-angles-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <h3 class="mx-auto mt-2"><?php echo app('translator')->get('custom.no-result'); ?></h3>
    <?php endif; ?>
</div>
<div class="container-fluid px-1 mb-3 mt-4">
    <div class="row px-3">
        <?php echo e($events->appends(request()->all())->links('pagination::bootstrap-4')); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/parts/events-list.blade.php ENDPATH**/ ?>