<div class="container d-flex flex-wrap">
    <?php $__currentLoopData = $event->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-3 p-2">
            <div class="event-media-container d-flex justify-content-center align-items-center rounded-3 position-relative">
                <div class="zoom-over">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </div>
                <img src="<?php echo e(asset('storage/' . $media->source)); ?>" alt="">
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php echo $__env->make('front.parts.events-media-zoom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/parts/events-media.blade.php ENDPATH**/ ?>