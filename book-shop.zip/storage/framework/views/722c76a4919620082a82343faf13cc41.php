<hr>
<div class="user-info d-flex align-items-center gap-3 mb-1">
    <div class="user_image d-flex justify-content-center align-items-center">
        <img src="<?php echo e(auth()->user()->display_image); ?>" alt="">
    </div>
    <div>
        <p class="mb-0 fw-bold"><?php echo e(auth()->user()->full_name); ?></p>
        <p class="mb-0" id="auth-attend-date"><?php echo e($attendance->created_at->format('Y/m/d h:i:sa')); ?></p>
    </div>
</div><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/parts/events-auth-attendance.blade.php ENDPATH**/ ?>