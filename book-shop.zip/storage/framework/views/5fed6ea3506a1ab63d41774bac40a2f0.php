<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo e($website_settings->site_title); ?> - <?php echo $__env->yieldContent('title'); ?></title>
<link rel="shortcut icon" href="imgs/logo.png">
<link rel="stylesheet" href="<?php echo e(asset('front')); ?>/libs/bootstrap/css/bootstrap<?php echo e(LaravelLocalization::getCurrentLocaleDirection() == 'rtl' ? '.rtl' : ''); ?>.min.css">
<link rel="stylesheet" href="<?php echo e(asset('front')); ?>/libs/fontawesome/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('front')); ?>/libs/owlcarousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo e(asset('front')); ?>/libs/owlcarousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="<?php echo e(asset('front')); ?>/libs/sweetalert2/sweet.css">
<link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/main.css">
<link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/responsive.css"><?php /**PATH C:\xampp\htdocs\book-shop\resources\views/front/partials/_head.blade.php ENDPATH**/ ?>